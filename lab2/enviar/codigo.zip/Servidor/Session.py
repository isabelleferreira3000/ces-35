class Session:
    def __init__(self, current_directory, username):
        self.current_directory = current_directory
        self.username = username
        self.local_directory = ""
